# README
该份代码集成了分页管理、基于多级反馈队列的多进程调度、
扩展shell（包括ls、mkdir、cd、touch、rm、cat、ps、kill）、支持日志（dmesg）、
攻击实例（overflow、overflow2、shellcode、inject）、
安全防护（包括基于hmac的完整性检验、缓冲区溢出防护、磁盘文件加密、文件资源访问控制）

每次修改项目文件后都要在command文件夹下`make install`

如果command增加了文件, 修改const.h中的PROG_FILE

注意每次使用前换新的磁盘，防止污染

**注：每次运行时，tty0会提示首先输入密钥，需要用户任意输入小于128字节字符串作为密钥后方可继续运行。**

下面给出部分功能测试的流程及注意事项。

#### （1）关于分页测试
- 开启bochsrc中的magic_break
- 通过info tab查看地址对应关系

#### （2）关于栈溢出的测试和防护
- 在shell运行shellcode, overflow, overflow2
- 在tty0查看检查信息
- 注释掉clock.c中的check_stack()可以不进行canary和eip的检查

#### （3）关于针对文件篡改的完整性检验测试
由于开启了权限控制，需要先赋予inject对文件读写的权限，为了测试需要按照如下操作进行（以inject pwd为例）：
- 对inject赋予权限：输入pro 13 /pwd
- 实施注入：输入inject pwd
- 测试完整性检验效果：输入pwd（此时由于文件已被篡改无法，校验值发生改变，无法执行）
- 实施注入后其他命令的执行会出现一些问题，需要重新编译启动

#### （4）关于ls的测试
- 同样需要先给ls授权，需要先输入：pro 13 /
