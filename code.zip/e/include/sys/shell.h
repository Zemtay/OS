#ifndef _SCARLETBORDER_SYS_SHELL_H_
#define _SCARLETBORDER_SYS_SHELL_H_

int initShell(char *root);

int changeCWD(char* target);

int getCWD(char* buf);

#endif