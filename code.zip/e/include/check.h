#ifndef CHECK_MD5_H
#define CHECK_MD5_H
 
typedef struct
{
    unsigned int count[2];
    unsigned int state[4];
    unsigned char buffer[64];   
}MD5_CTX;
  
                         
#define F(x,y,z) ((x & y) | (~x & z))
#define G(x,y,z) ((x & z) | (y & ~z))
#define H(x,y,z) (x^y^z)
#define I(x,y,z) (y ^ (x | ~z))
#define ROTATE_LEFT(x,n) ((x << n) | (x >> (32-n)))
#define FF(a,b,c,d,x,s,ac) \
          { \
          a += F(b,c,d) + x + ac; \
          a = ROTATE_LEFT(a,s); \
          a += b; \
          }
#define GG(a,b,c,d,x,s,ac) \
          { \
          a += G(b,c,d) + x + ac; \
          a = ROTATE_LEFT(a,s); \
          a += b; \
          }
#define HH(a,b,c,d,x,s,ac) \
          { \
          a += H(b,c,d) + x + ac; \
          a = ROTATE_LEFT(a,s); \
          a += b; \
          }
#define II(a,b,c,d,x,s,ac) \
          { \
          a += I(b,c,d) + x + ac; \
          a = ROTATE_LEFT(a,s); \
          a += b; \
          }  


void MD5Init(MD5_CTX *context);
void MD5Update(MD5_CTX *context,unsigned char *input,unsigned int inputlen);
void MD5Final(MD5_CTX *context,unsigned char digest[16]);
void MD5Transform(unsigned int state[4],unsigned char block[64]);
void MD5Encode(unsigned char *output,unsigned int *input,unsigned int len);
void MD5Decode(unsigned int *output,unsigned char *input,unsigned int len);

struct check_t {
	char filepath[32]; // 文件路径
	int byteCount;     // 文件大小
	unsigned char checksum[16];      // 校验值
};

typedef struct {
    MD5_CTX inner_ctx;
    MD5_CTX outer_ctx;
    unsigned char inner_key[64];
    unsigned char outer_key[64];
} HMAC_CTX;


// PUBLIC int Check(char* filepath, int byteCount, unsigned char result[16]);
PUBLIC int Check(char* filepath, int byteCount, unsigned char key[], int key_len, unsigned char result[16]);


#define	NR_CHECKFILES 20
PUBLIC struct check_t check_table[NR_CHECKFILES];

#endif