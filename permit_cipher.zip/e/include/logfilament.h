#ifndef _SCARLETBORDER_LOGFILAMENT_H_
#define _SCARLETBORDER_LOGFILAMENT_H_



void PrintLogTail_User(int tail);

void SwitchLogLevel_User(int level);

#endif